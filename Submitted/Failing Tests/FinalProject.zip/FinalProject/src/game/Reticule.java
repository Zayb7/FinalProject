package game;

import java.awt.Graphics;

public class Reticule {
	//variables
	private int row, col;
	
	//methods
	public void draw(Graphics g){
		
	}
}
