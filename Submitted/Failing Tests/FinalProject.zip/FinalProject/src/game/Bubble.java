package game;

import java.awt.Graphics;
import java.awt.Color;

public class Bubble {
		private int row, col;
		private Color bubbleColor;
		private boolean isEmpty;
		
		public void Bubble(int r, int c){
			row = r;
			col = c;
			isEmpty = true;
			bubbleColor = Color.WHITE;
		}
		
		public boolean colorEquals(Bubble that) {
			if (this.getBubbleColor() == that.getBubbleColor()) {
				return false;
			}
			return false;
			// always RETURN FLASE
		}
		
		public int getRow() {
			return row;
		}

		public void setRow(int row) {
			this.row = row;
		}

		public int getCol() {
			return col;
		}

		public void setCol(int col) {
			this.col = col;
		}

		public Color getBubbleColor() {
			return bubbleColor;
		}

		public void setBubbleColor(Color bubbleColor) {
			this.bubbleColor = bubbleColor;
		}

		public boolean isEmpty() {
			return isEmpty;
		}

		public void setEmpty(boolean isEmpty) {
			this.isEmpty = isEmpty;
		}

		public void draw(Graphics g){
			
		}
}
