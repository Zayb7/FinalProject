package game;

import java.awt.Graphics;
import java.util.ArrayList;
import java.util.Timer;

import javax.swing.JPanel;

public class Board extends JPanel {
	//variables
	private Bubble[][] bubbleBoard;
	private int height = 0, width = 0;
	private int movesMade;
	private int maximum_moves = 10; 
	private Timer timer;
	private boolean end;
	public int getMovesMade() {
		return movesMade;
	}

	public void setMovesMade(int movesMade) {
		this.movesMade = movesMade;
	}

	public int getMaximum_moves() {
		return maximum_moves;
	}

	public void setMaximum_moves(int maximum_moves) {
		this.maximum_moves = maximum_moves;
	}

	public Timer getTimer() {
		return timer;
	}

	public void setTimer(Timer timer) {
		this.timer = timer;
	}

	public boolean isEnd() {
		return end;
	}

	public void setEnd(boolean end) {
		this.end = end;
	}

	public String getPlayerName() {
		return playerName;
	}

	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}

	public int getHighScore() {
		return highScore;
	}

	public void setHighScore(int highScore) {
		this.highScore = highScore;
	}

	public void setBubbleBoard(Bubble[][] bubbleBoard) {
		this.bubbleBoard = bubbleBoard;
	}

	private String playerName;
	private int highScore;

	//methods
	public void Board(){
		bubbleBoard = new Bubble[width][height];
		
	}

	public int getIntTimer() {
		return 0;
	}

	public void setIntTimer(int timer) {
		//TODO: setup int to timer conversion
	}

	public void swap(Bubble one, Bubble two){
		
	}
	
	public void draw(Graphics g){
		
	}
	
	public void detectMaster(){
		
	}
	
	public ArrayList<Bubble> detectHelper(Bubble aBubble){
		return null;
	}
	
	public void fallHelper(Bubble aBubble){
		
		
	}
	
	public void fallMaster(){
		
	}
	
	public void moveReticle(int newRow, int newCol){
		
	}
	
	public void checkEnd(){
		
	}
	
	public int calculateScore(){
		return 0;
	}
	
	//getters and setters
	public Bubble[][] getBubbleBoard() {
		return bubbleBoard;
	}
	
	public Bubble getBubble(int row, int col){
		return null;
	}
	
	public void setBubble(Bubble aBubble){
		
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}
	
	
	
}
